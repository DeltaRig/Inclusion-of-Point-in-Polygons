//
//  Modelo.hpp
//  OpenGLTest
//
//  Created by Márcio Sarroglia Pinho on 22/09/20.
//  Copyright © 2020 Márcio Sarroglia Pinho. All rights reserved.
//

#ifndef Modelo_h
#define Modelo_h

#include "Poligono.h"

class Modelo: public Poligono
{
    int nroLinhas, nroColunas;
    int matriz[][6];
public:
    void desenhaLinhas();
    void imprimeMatrizModelo();
    Modelo LeModeloArquivo(const char *nome);

};

#endif /* Modelo_hpp */
