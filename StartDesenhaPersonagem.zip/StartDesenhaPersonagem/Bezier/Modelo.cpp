//
//  Modelo.cpp
//  OpenGLTest
//
//  Created by Márcio Sarroglia Pinho on 22/09/20.
//  Copyright © 2020 Márcio Sarroglia Pinho. All rights reserved.
//
#include <fstream>
#include "Modelo.h"


void Modelo::desenhaLinhas()
{
    glBegin(GL_LINE_STRIP);
    for (int i=0; i<Vertices.size(); i++)
        glVertex3f(Vertices[i].x,Vertices[i].y,Vertices[i].z);
    glEnd();
}

void Modelo::imprimeMatrizModelo()
{
    cout << "Imprime m " << endl;
    for (int i = 0; i < nroColunas; i++)
    {
        for (int j = 0; j < nroLinhas; j++)
        {
            cout << matriz[i][j] << endl;
        }
    }
}

// LE ARQUIVO COM OS MODELOS E SALVA MODELO

Modelo Modelo::LeModeloArquivo(const char *nome)
{
    ifstream input;
    input.open(nome, ios::in);
    if (!input)
    {
        cout << "Erro ao abrir " << nome << ". " << endl;
        exit(0);
    }

    cout << "Lendo arquivo " << nome << "...";

    unsigned int nColunas;
    unsigned int nLinhas;
    string info;

    input >> info;
    Modelo modelo;
    if(info == "#OBJETO")
    {
        int nLinhas, nColunas;
        input >> nLinhas >> nColunas;


        modelo.nroColunas = nColunas;
        modelo.nroLinhas = nLinhas;

        for(int i = 0; i < nLinhas; i++) {
            for(int j = 0; j < nColunas; j++) {
                input >> modelo.matriz[i][j];
            }
        }
    }

    return modelo;
}

